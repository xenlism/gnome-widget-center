/** Windows logo */

// Auto-converted from archey4's Python logo module.
// LOGO strings keep the original '{c[N]}' placeholders, which index into COLORS.

export const COLORS = [
    "#5c5cff",
    "#ff0000",
    "#00ff00",
    "#cdcd00",
];

export const LOGO = [
    "{c[0]}         {c[1]},.=:!!t3Z3z.,{c[0]}               ",
    "{c[0]}        {c[1]}.tt:::tt333EE3{c[0]} {c[2]},{c[0]}             ",
    "{c[0]}        {c[1]}Et:::ztt33EEE;{c[0]} {c[2]}@Ee.,{c[0]}      {c[2]}..,{c[0]}",
    "{c[0]}       {c[1]};tt:::tt333EE7{c[0]} {c[2]};EEEEEEttttt33#{c[0]}",
    "{c[0]}      {c[1]}.Et:::zt333EEQ'{c[0]}{c[2]}.SEEEEEttttt33Q;{c[0]}",
    "{c[0]}      {c[1]}it::::tt333EEF{c[0]} {c[2]}@EEEEEEttttt33F{c[0]} ",
    "{c[0]}     {c[1]};3=*^```'*4EEV{c[0]} {c[2]}:EEEEEEttttt33@'{c[0]} ",
    "{c[0]}     ,.=::::it=.,{c[1]} `{c[0]} {c[2]}@EEEEEEtttz33QF{c[0]}  ",
    "{c[0]}    ;::::::::zt33){c[0]} {c[3]}, {c[2]}'4EEEtttji3P*{c[0]}   ",
    "{c[0]}   ,l::::::::tt33'{c[3]} Z3z..{c[2]}  `` {c[3]},..g:{c[0]}   ",
    "{c[0]}   y::::::::zt33;{c[0]} {c[3]}AEEEtttt::::ztF{c[0]}    ",
    "{c[0]}  ;:::::::::t33J{c[0]} {c[3]};EEEttttt::::t3'{c[0]}    ",
    "{c[0]} ,E;:::::::zt33:{c[0]} {c[3]}@EEEtttt::::z3;{c[0]}     ",
    "{c[0]} {{3=*^```'*4E3P{c[0]} {c[3]};EEEtttt:::::tZ{c[0]}      ",
    "{c[0]}             `{c[0]} {c[3]}`:EEEEttt:::::z`{c[0]}      ",
    "{c[0]}                 {c[3]}'VEzjt:;;z>*`{c[0]}       ",
];

// Registry of all variants defined by this logo module, keyed by variant name.
// 'default' is the primary logo archey4 uses unless a variant is explicitly selected.
export const VARIANTS = {
    "default": {colors: COLORS, logo: LOGO},
};

export default VARIANTS.default;
