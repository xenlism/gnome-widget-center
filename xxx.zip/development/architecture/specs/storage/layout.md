# Storage Layout
