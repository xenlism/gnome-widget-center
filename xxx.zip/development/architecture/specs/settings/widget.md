# Widget Settings Spec
