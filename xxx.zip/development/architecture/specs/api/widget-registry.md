# Widget Registry API
