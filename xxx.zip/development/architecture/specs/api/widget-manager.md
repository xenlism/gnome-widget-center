# Widget Manager API
