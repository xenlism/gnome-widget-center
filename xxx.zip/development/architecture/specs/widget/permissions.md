# Widget Permissions
