export const COLORS = [ "#00ff00", "#ffffff" ];

export const LOGO = [ "{c[0]}          -o          o-         ", "{c[0]}           +hydNNNNdyh+          ", "{c[0]}         +mMMMMMMMMMMMMm+        ", "{c[0]}       `dMM{c[1]}m:{c[0]}NMMMMMMN{c[1]}:m{c[0]}MMd`      ", "{c[0]}       hMMMMMMMMMMMMMMMMMMh      ", "{c[0]}   ..  yyyyyyyyyyyyyyyyyyyy  ..  ", "{c[0]} .mMMm`MMMMMMMMMMMMMMMMMMMM`mMMm.", "{c[0]} :MMMM-MMMMMMMMMMMMMMMMMMMM-MMMM:", "{c[0]} :MMMM-MMMMMMMMMMMMMMMMMMMM-MMMM:", "{c[0]} :MMMM-MMMMMMMMMMMMMMMMMMMM-MMMM:", "{c[0]} :MMMM-MMMMMMMMMMMMMMMMMMMM-MMMM:", "{c[0]} -MMMM-MMMMMMMMMMMMMMMMMMMM-MMMM-", "{c[0]}  +yy+ MMMMMMMMMMMMMMMMMMMM +yy+ ", "{c[0]}       mMMMMMMMMMMMMMMMMMMm      ", "{c[0]}       `/++MMMMh++hMMMM++/`      ", "{c[0]}           MMMMo  oMMMM          ", "{c[0]}           MMMMo  oMMMM          ", "{c[0]}           oNMm-  -mMNs          " ];

export const VARIANTS = {
    default: {
        colors: COLORS,
        logo: LOGO
    }
};

export default VARIANTS.default;