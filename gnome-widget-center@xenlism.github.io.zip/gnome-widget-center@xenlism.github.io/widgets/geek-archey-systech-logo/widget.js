// widgets/geek-archey-systech-logo/widget.js
//
// The "logo only" half of the Archey pair (2026-08-09 split): this
// widget shows NOTHING but the archey4/neofetch-style ASCII distro logo,
// centered in a fixed 1x1 block (11x11 cells * 16px = 176x176px, see
// lib/blockSizeManager.js's BLOCK_TYPES table). No system-info text, no
// color palette - pair it with widgets/geek-archey-systech-squre (now
// text-only) if you want both side by side on the desktop.
//
// Distro selection / auto-detection / logo loading all mirror
// widgets/geek-archey-systech-squre/widget.js's own (now-removed) logo
// code exactly - see that file's git history for the shared origin -
// just without any of the system-info-fetching machinery this widget
// has no use for.

import St from 'gi://St';
import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import {
    SHADOW_DEFAULTS, shadowBoxShadowCss as _shadowBoxShadowCss, toCssColor as _toCssColor,
} from '../../lib/widgetVisualKit.js';

const CARD_PADDING = 12;

// Every distro key that has a matching ./logos/<key>.js module (kept in
// sync with config.json's dropdown options and the logos/ directory).
const DISTRO_KEYS = [
    'alpine', 'android', 'arch', 'armbian', 'buildroot', 'bunsenlabs',
    'centos', 'crunchbang', 'darwin', 'debian', 'devuan', 'elementary',
    'endeavouros', 'enso', 'fedora', 'freebsd', 'gentoo', 'guix', 'kali',
    'linux', 'linuxmint', 'manjaro', 'moevalent', 'netbsd', 'nixos',
    'nobara', 'openbsd', 'opensuse', 'parabola', 'pop', 'quirinux',
    'raspbian', 'rhel', 'rocky', 'siduction', 'slackware', 'ubuntu',
    'univalent', 'windows',
];

// A few /etc/os-release `ID=`/`ID_LIKE=` values that don't spell their
// distro key the same way we do (or share one logo across near-clones).
const DISTRO_ID_ALIASES = {
    'opensuse-leap': 'opensuse',
    'opensuse-tumbleweed': 'opensuse',
    suse: 'opensuse',
    sles: 'opensuse',
    ol: 'rhel', // Oracle Linux
    rhel: 'rhel',
    almalinux: 'rocky', // closest available family logo
    mint: 'linuxmint',
    artix: 'arch',
};

// Fallback mark shown before a logo module has finished loading (or if
// loading one ever fails) - NOT copied from archey4's own logo files,
// just a same-spirit placeholder glyph.
const GENERIC_ART = {
    color: '#8be9fd',
    art: [
        '     .--.',
        '    ( oo )',
        '     |==|',
        '    /|  |\\',
        '   ^ \'--\' ^',
        '',
        '   L I N U X',
    ],
};

/** @private Escapes text for safe embedding inside Pango markup. */
function _markupEscape(text) {
    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

/** @private Turns one archey4-style LOGO line (containing '{c[N]}' color
 * placeholders) into a Pango markup string, wrapping each colored run in
 * its own <span foreground="..."> using the matching entry of `colors`. */
function _logoLineToMarkup(line, colors) {
    let markup = '';
    let currentColor = null;
    let openSpan = false;
    const re = /\{c\[(\d+)\]\}|([^{]+)/g;
    let match;
    while ((match = re.exec(line)) !== null) {
        if (match[1] !== undefined) {
            const color = colors[Number(match[1])] ?? colors[0] ?? '#ffffff';
            if (color !== currentColor) {
                if (openSpan)
                    markup += '</span>';
                markup += `<span foreground="${color}">`;
                currentColor = color;
                openSpan = true;
            }
        } else {
            markup += _markupEscape(match[2]);
        }
    }
    if (openSpan)
        markup += '</span>';
    return markup;
}

export default class GeekArcheySystechLogoWidget {
    /**
     * @param {WidgetAPI} api - see development/docs/WIDGET_API.md §5.
     */
    constructor(api) {
        this._api = api;
        this._settings = api.settings;

        // Logo state: only ever holds the ONE currently-selected distro's
        // logo module (never a cache of all of them) plus which distro
        // key it belongs to, so a stale in-flight import() can't clobber
        // a newer selection.
        this._logoDistroKey = null;
        this._logoModule = null;
        this._logoLoadToken = 0;
    }

    buildActor() {
        this._actor = new St.Bin({
            style_class: 'geek-archey-systech-logo-root',
            x_align: Clutter.ActorAlign.CENTER,
            y_align: Clutter.ActorAlign.CENTER,
        });

        this._asciiLabel = new St.Label({style_class: 'geek-archey-systech-logo-ascii'});
        this._asciiLabel.clutter_text.set_use_markup(true);
        this._asciiLabel.clutter_text.set_line_wrap(false);

        this._actor.set_child(this._asciiLabel);

        this._render();
        return this._actor;
    }

    enable() {
        this._ensureDistroDetected();
        this._loadLogo(this._settings.distro ?? 'linux');
    }

    disable() {
        // Nothing to tear down - no timers, no subprocesses, no DBus.
    }

    getDefaultSettings() {
        return {
            ...SHADOW_DEFAULTS,
            distro: 'linux',
            // Set true once _detectLinuxDistro() has run and written its
            // guess into `distro` - keeps first-run auto-detection from
            // overwriting a distro the user later picked by hand.
            distroDetected: false,
            backgroundColor: '#FFFFFF00',
            cornerRadius: 18,
        };
    }

    // Re-render immediately so a color/radius/distro change in the
    // Control Center shows up right away.
    onSettingsChanged() {
        const distroKey = this._settings.distro ?? 'linux';
        if (distroKey !== this._logoDistroKey)
            this._loadLogo(distroKey);
        this._render();
    }

    /** @private First-run only (guarded by the persisted `distroDetected`
     * flag): reads /etc/os-release and, if it maps to one of our
     * DISTRO_KEYS, sets that as the default `distro` setting. */
    _ensureDistroDetected() {
        if (this._settings.distroDetected)
            return;

        this._settings.distro = this._detectLinuxDistro();
        this._settings.distroDetected = true;
        this._api.saveSettings?.(this._settings);
    }

    /** @private Best-effort /etc/os-release -> DISTRO_KEYS lookup. */
    _detectLinuxDistro() {
        try {
            const [ok, contents] = GLib.file_get_contents('/etc/os-release');
            if (!ok)
                return 'linux';

            const text = new TextDecoder().decode(contents);
            const clean = (v) => (v ?? '').trim().replace(/^"|"$/g, '');
            const id = clean(text.match(/^ID=(.*)$/m)?.[1]);
            const idLike = clean(text.match(/^ID_LIKE=(.*)$/m)?.[1]);

            const candidates = [id, ...idLike.split(/\s+/)].filter(Boolean);
            for (const candidate of candidates) {
                const key = DISTRO_ID_ALIASES[candidate] ?? candidate;
                if (DISTRO_KEYS.includes(key))
                    return key;
            }
            return 'linux';
        } catch (e) {
            return 'linux';
        }
    }

    /** @private Loads exactly one logo module - `./logos/${distroKey}.js`
     * - via a dynamic import(), and only that one. Re-entrant-safe via
     * `token`: if the user flips through several distros quickly, only
     * the *last* import() to resolve is allowed to update
     * this._logoModule/_render(). */
    _loadLogo(distroKey) {
        const token = ++this._logoLoadToken;
        const key = distroKey === 'generic' ? null : distroKey;

        const applyFallback = () => {
            if (token !== this._logoLoadToken)
                return;
            this._logoDistroKey = distroKey;
            this._logoModule = null; // _render() falls back to GENERIC_ART
            this._render();
        };

        if (!key) {
            applyFallback();
            return;
        }

        import(`./logos/${key}.js`).then(module => {
            if (token !== this._logoLoadToken)
                return; // a newer selection already superseded this load
            this._logoDistroKey = distroKey;
            this._logoModule = module;
            this._render();
        }).catch(e => {
            logError(e, `geek-archey-systech-logo: failed to load logo for "${distroKey}"`);
            applyFallback();
        });
    }

    /** @private repaints the card from this._settings - never touches
     * the network or spawns anything, so it's safe to call as often as
     * needed. */
    _render() {
        const backgroundColor = _toCssColor(this._settings.backgroundColor ?? '#FFFFFF00', '#FFFFFF00');
        const cornerRadius = this._settings.cornerRadius ?? 18;

        this._actor.set_style(
            `background-color: ${backgroundColor}; border-radius: ${cornerRadius}px; padding: ${CARD_PADDING}px;` +
            _shadowBoxShadowCss(this._settings)
        );

        let accent = GENERIC_ART.color;
        let markup;
        if (this._logoModule) {
            const variant = this._logoModule.default; // {colors, logo}
            accent = variant.colors[0] ?? GENERIC_ART.color;
            markup = variant.logo.map(line => _logoLineToMarkup(line, variant.colors)).join('\n');
        } else {
            accent = GENERIC_ART.color;
            markup = _markupEscape(GENERIC_ART.art.join('\n'));
        }

        // Fixed 1x1 block is 176x176px (11x11 cells, see
        // lib/blockSizeManager.js) minus 2*CARD_PADDING - a small font
        // keeps every bundled logo comfortably inside that, without
        // needing per-distro tuning.
        this._asciiLabel.set_style(
            `font-family: monospace; font-size: 8px; line-height: 1.15; color: ${accent}; white-space: pre;`
        );
        this._asciiLabel.clutter_text.set_markup(markup);
    }
}
