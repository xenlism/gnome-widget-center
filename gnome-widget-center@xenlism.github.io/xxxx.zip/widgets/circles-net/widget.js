import Clutter from "gi://Clutter";

import St from "gi://St";

import GLib from "gi://GLib";

import Gio from "gi://Gio";

import Cairo from "cairo";

import { SystemMetricsService } from "../../lib/systemMetricsApi.js";

import { SHADOW_DEFAULTS, cardStyleCss as _cardStyleCss, hexToRgba as _hexToRgba, toCssColor as _toCssColor, parseFontDescription as _parseFontDescription, BORDER_DEFAULTS, OPACITY_DEFAULTS } from "../../lib/widgetVisualKit.js";

import { createLayeredCard, applyLayeredCardStyle } from "../../lib/shell/cardLayers.js";

import {configJsonDefaults} from '../../lib/widgetConfigDefaults.js';
const RING_SIZE = 128;

const RING_GAP = 4;

const MIN_DYNAMIC_SCALE_BYTES_PER_SEC = 8 * 1024;

const SCALE_HEADROOM = 1.25;

const SCALE_DECAY = .85;

function _formatRate(bytesPerSec) {
    const units = [ "B/s", "KB/s", "MB/s", "GB/s" ];
    let value = Math.max(0, bytesPerSec);
    let i = 0;
    while (value >= 1024 && i < units.length - 1) {
        value /= 1024;
        i++;
    }
    const decimals = i > 0 && value < 10 ? 1 : 0;
    return `${value.toFixed(decimals)} ${units[i]}`;
}

function _adaptiveFraction(bytesPerSec, previousScale) {
    const rate = Math.max(0, Number.isFinite(bytesPerSec) ? bytesPerSec : 0);
    const scale = Math.max(MIN_DYNAMIC_SCALE_BYTES_PER_SEC, rate * SCALE_HEADROOM, (Number.isFinite(previousScale) ? previousScale : 0) * SCALE_DECAY);
    return {
        scale: scale,
        fraction: Math.min(1, rate / scale)
    };
}

export default class CirclesNetWidget {
    constructor(api) {
        this._api = api;
        this._settings = api.settings;
        this._metrics = new SystemMetricsService;
        this._timerId = null;
        this._pressId = null;
        this._downloadFraction = 0;
        this._uploadFraction = 0;
        this._downloadScale = MIN_DYNAMIC_SCALE_BYTES_PER_SEC;
        this._uploadScale = MIN_DYNAMIC_SCALE_BYTES_PER_SEC;
    }
    buildActor() {
        this._layers = createLayeredCard({
            contentStyleClass: "circles-net-root"
        });
        this._actor = this._layers.root;
        const outerBox = new St.BoxLayout({
            orientation: Clutter.Orientation.VERTICAL,
            x_expand: true,
            y_expand: true
        });
        this._layers.content.add_child(outerBox);
        outerBox.set_style("padding: 14px;");
        this._stack = new St.Widget({
            layout_manager: new Clutter.BinLayout,
            width: RING_SIZE,
            height: RING_SIZE,
            x_align: Clutter.ActorAlign.CENTER,
            y_align: Clutter.ActorAlign.CENTER,
            x_expand: true,
            y_expand: true
        });
        outerBox.add_child(this._stack);
        this._ringArea = new St.DrawingArea({
            width: RING_SIZE,
            height: RING_SIZE
        });
        this._stack.add_child(this._ringArea);
        this._repaintId = this._ringArea.connect("repaint", () => this._onRepaint());
        const textBox = new St.BoxLayout({
            orientation: Clutter.Orientation.VERTICAL,
            x_align: Clutter.ActorAlign.CENTER,
            y_align: Clutter.ActorAlign.CENTER,
            x_expand: true,
            y_expand: true
        });
        this._labelLabel = new St.Label({
            text: "NET",
            style_class: "circles-net-label"
        });
        this._downloadLabel = new St.Label({
            style_class: "circles-net-download"
        });
        this._uploadLabel = new St.Label({
            style_class: "circles-net-upload"
        });
        textBox.add_child(this._labelLabel);
        textBox.add_child(this._downloadLabel);
        textBox.add_child(this._uploadLabel);
        this._stack.add_child(textBox);
        this._render();
        this._tick();
        this._applyClickHandler();
        return this._actor;
    }
    enable() {
        this._startTimer();
    }
    disable() {
        this._stopTimer();
        if (this._repaintId !== null && this._ringArea) {
            this._ringArea.disconnect(this._repaintId);
            this._repaintId = null;
        }
        this._removeClickHandler();
    }
    getDefaultSettings() {
        return {
            ...configJsonDefaults(import.meta.url),
            ...SHADOW_DEFAULTS,
            ...BORDER_DEFAULTS,
            ...OPACITY_DEFAULTS,
        };
    }
    onSettingsChanged() {
        this._render();
        this._startTimer();
    }
    _startTimer() {
        this._stopTimer();
        const seconds = Math.max(1, this._settings.refreshRateSeconds ?? 2);
        this._tick();
        this._timerId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, seconds, () => {
            this._tick();
            return GLib.SOURCE_CONTINUE;
        });
        this._applyClickHandler();
    }
    _stopTimer() {
        if (this._timerId !== null) {
            GLib.source_remove(this._timerId);
            this._timerId = null;
        }
    }
    async _tick() {
        const {totalRxBytesPerSec: totalRxBytesPerSec, totalTxBytesPerSec: totalTxBytesPerSec} = await this._metrics.getNetworkUsage();
        const download = _adaptiveFraction(totalRxBytesPerSec, this._downloadScale);
        const upload = _adaptiveFraction(totalTxBytesPerSec, this._uploadScale);
        this._downloadScale = download.scale;
        this._uploadScale = upload.scale;
        this._downloadFraction = download.fraction;
        this._uploadFraction = upload.fraction;
        this._downloadLabel.set_text(`↓ ${_formatRate(totalRxBytesPerSec)}`);
        this._uploadLabel.set_text(`↑ ${_formatRate(totalTxBytesPerSec)}`);
        if (this._ringArea) this._ringArea.queue_repaint();
    }
    _applyClickHandler() {
        this._removeClickHandler();
        const path = this._settings.launchAppPath ?? "";
        const launchEnabled = this._settings.launchEnabled ?? false;
        if (!launchEnabled || !path) {
            this._actor.reactive = false;
            return;
        }
        this._actor.reactive = true;
        this._pressId = this._actor.connect("button-press-event", (_actor, event) => {
            if (event.get_button() !== Clutter.BUTTON_PRIMARY) return Clutter.EVENT_PROPAGATE;
            if (event.get_state() & Clutter.ModifierType.MOD4_MASK) return Clutter.EVENT_PROPAGATE;
            this._launchApp();
            return Clutter.EVENT_STOP;
        });
    }
    _removeClickHandler() {
        if (this._pressId !== null && this._actor) {
            this._actor.disconnect(this._pressId);
            this._pressId = null;
        }
    }
    _launchApp() {
        const path = this._settings.launchAppPath ?? "";
        if (!(this._settings.launchEnabled ?? false) || !path) return;
        try {
            const appInfo = Gio.DesktopAppInfo.new_from_filename(path);
            if (appInfo) appInfo.launch([], null); else this._api.logger.info(`circles-net: could not read .desktop file at ${path}`);
        } catch (e) {
            this._api.logger.info(`circles-net: failed to launch ${path}: ${e}`);
        }
    }
    _render() {
        const backgroundColor = _toCssColor(this._settings.backgroundColor, "#FFFFFF00");
        const cornerRadius = this._settings.cornerRadius ?? 18;
        applyLayeredCardStyle(this._layers, this._settings, {
            cornerRadiusFallback: 18
        }, false);
        const labelColor = _toCssColor(this._settings.labelColor, "#FFFFFFB3");
        const downloadColor = _toCssColor(this._settings.downloadColor, "#5AC8FAFF");
        const uploadColor = _toCssColor(this._settings.uploadColor, "#FF9F0AFF");
        const labelFont = _parseFontDescription(this._settings.labelFont ?? "Sans 12", "Sans", 12);
        const valueFont = _parseFontDescription(this._settings.percentFont ?? "Sans Bold 14", "Sans Bold", 14);
        this._labelLabel.set_style(`color: ${labelColor}; font-family: ${labelFont.family}; ` + `font-size: ${labelFont.size}px; text-align: center; margin-bottom: 2px;`);
        this._downloadLabel.set_style(`color: ${downloadColor}; font-family: ${valueFont.family}; ` + `font-size: ${valueFont.size}px; font-weight: bold; text-align: center;`);
        this._uploadLabel.set_style(`color: ${uploadColor}; font-family: ${valueFont.family}; ` + `font-size: ${valueFont.size}px; font-weight: bold; text-align: center;`);
        if (this._ringArea) this._ringArea.queue_repaint();
    }
    _onRepaint() {
        const cr = this._ringArea.get_context();
        cr.setOperator(Cairo.Operator.CLEAR);
        cr.paint();
        cr.setOperator(Cairo.Operator.OVER);
        const thickness = Math.max(2, this._settings.ringThickness ?? 9);
        const baseColor = _hexToRgba(this._settings.circleBaseColor ?? "#FFFFFF26");
        const cx = RING_SIZE / 2;
        const cy = RING_SIZE / 2;
        const startAngle = -Math.PI / 2;
        const outerRadius = RING_SIZE / 2 - thickness / 2 - 2;
        const rings = [ {
            radius: outerRadius,
            fraction: this._downloadFraction,
            color: this._settings.downloadColor ?? "#5AC8FAFF"
        }, {
            radius: outerRadius - (thickness + RING_GAP),
            fraction: this._uploadFraction,
            color: this._settings.uploadColor ?? "#FF9F0AFF"
        } ];
        cr.setLineWidth(thickness);
        cr.setLineCap(Cairo.LineCap.ROUND);
        for (const ring of rings) {
            if (ring.radius <= 0) continue;
            cr.setSourceRGBA(baseColor.r, baseColor.g, baseColor.b, baseColor.a);
            cr.arc(cx, cy, ring.radius, 0, 2 * Math.PI);
            cr.stroke();
            const fraction = Math.max(0, Math.min(1, ring.fraction));
            if (fraction > 0) {
                const {r: r, g: g, b: b, a: a} = _hexToRgba(ring.color);
                cr.setSourceRGBA(r, g, b, a);
                cr.arc(cx, cy, ring.radius, startAngle, startAngle + fraction * 2 * Math.PI);
                cr.stroke();
            }
        }
        cr.$dispose();
    }
}